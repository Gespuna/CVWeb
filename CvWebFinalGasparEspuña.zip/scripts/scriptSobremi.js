const button = document.getElementById("math");
button.addEventListener("click", function() {
  const randomNumber = Math.random();
  document.getElementById("result").innerHTML = randomNumber;
});