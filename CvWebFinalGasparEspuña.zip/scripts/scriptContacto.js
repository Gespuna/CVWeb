function validarFormulario() {
  var nombreInput = document.getElementById('nombre').value;
  var emailInput = document.getElementById('email').value;
  var telefonoInput = document.getElementById('phone').value;
  console.log(nombreInput);
  var nombrePattern = /^[a-zA-Z\s]+$/;
  var telefonoPattern = /^\d{10}$/;
  var emailPattern = /.+@gmail\.com$/;

  if (!nombrePattern.test(nombreInput)) {
    alert('Ingrese un nombre válido sin números');
    return false;
  }

  if (!telefonoPattern.test(telefonoInput)) {
    alert('Ingrese un número de teléfono válido que tenga 10 dígitos');
    return false;
  }

  if (!emailPattern.test(emailInput)) {
    alert('Ingrese un correo electrónico válido de Gmail');
    return false;
  }

  return true;
}