const currentDate = new Date();

const fechaFormateada = currentDate.toLocaleDateString('es-ES');

document.getElementById("date").innerHTML = "&copy;"+ fechaFormateada;
// Aquí ponemos un date con lo que demostramos que sabemos como usarlo
const button = document.getElementById("button");

button.addEventListener("click", function() {
    console.log("Se hizo clic en el botón");
    const url = "assets/DownloadPDFfile.jpg";
    const fileName = "DownloadPDFfile.jpg";
    // En esta parte hago que al pulsar el boton descargar se puedan descargar la imagen del Cv en una nueva pestaña usando los event
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    link.target= "_blank"
    link.click();
  });

  const button2= document.getElementById("button2")
  // con esta uso los Jqueries para poner la pagina en modo oscuro y claro
  $(document).ready(function(){
    var isClicked = false;
  
    $("#button2").click(function(){
      if (!isClicked) {
        $("body, #izq, header, footer").css("background-color", "black");
        $("p, h1, h2").css("color", "white");
        isClicked = true;
      } else {
        $("body, #izq, header, footer").css("background-color", ""); 
        $("p, h1, h2").css("color", ""); 
        isClicked = false;
      }
    });
  });
  window.addEventListener('resize', function() {
    if (window.innerWidth < 730) {
      document.querySelector('footer').style.display = 'grid-row:3';
      document.querySelector('#der').style.backgroundColor = 'transparent';
      document.querySelector('body').style.display = 'grid';
  
    } 
    else {
       document.querySelector('footer').style.display = 'initial';
      document.querySelector('#der').style.backgroundColor = '#000';
      document.querySelector('body').style.display = 'initial';

     }
    //  Aquí intenté que la página se volviese más leible en caso de que se minimizara el tamaño ya que es su punto debil y la visualizacion es mas dificil. Usé los Jqueries
  
  });
  
  button2.addEventListener("dblclick", function() {
  window.location.href = ("https://www.google.com/search?q=huevos+de+pascua+hospitalet&sa=X&biw=1821&bih=865&tbm=shop&sxsrf=APwXEdfcnlObSt_ngnUsfJ1PyyfL2z4SXg%3A1684248383470&ei=P5djZPmBHOmtkdUP4p2K-AM&ved=0ahUKEwi5nfCUivr-AhXpVqQEHeKOAj8Q4dUDCAg&uact=5&oq=huevos+de+pascua+hospitalet&gs_lcp=Cgtwcm9kdWN0cy1jYxADMgUIIRCgAToICAAQgAQQsAM6DQgAEBgQgAQQsAMQiwM6CwiuARDKAxCwAxAnOgcIABANEIAEOgwIABANEBgQgAQQiwM6BAgjECc6CggAEBgQgAQQiwM6BwgAEBMQgAQ6CAgAEBYQHhATOg0IABAWEB4QGBATEIsDOgcIABAYEIAEOgsIABAWEB4QGBCLAzoICAAQFhAeEBg6BwghEKABEApQgglYojVgwzZoAXAAeACAAYEHiAHFGZIBDjIuMTAuMC4xLjEuMC4xmAEAoAEByAEMuAECwAEB&sclient=products-cc");
 
 
   
});
  
  