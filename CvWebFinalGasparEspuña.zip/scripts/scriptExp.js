const miArray= ["Perseveracia", "Compromiso", "Paciencia", "Capacidad lógica"]

document.getElementById("uno").innerHTML= miArray[0]

document.getElementById("dos").innerHTML= miArray[1]

document.getElementById("tres").innerHTML= miArray[2]

document.getElementById("cuatro").innerHTML= miArray[3]