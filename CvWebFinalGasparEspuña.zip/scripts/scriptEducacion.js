let datosJSON = {
    grado: "Comunicación Audiovisual",
    universidad: "Universidad de Barcelona",
    periodo_grado: "2015 - 2020",
    cursos: [
      {
        nombre: "Curso Python",
        institucion: "Escola Espai",
        periodo: "2020 - 2021"
      },
      {
        "nombre": "Soastica Jesus López",
        "institucion": "Curso Machine Learning",
        "periodo": "2020 - 2021"
      },
      {
        "nombre": "Curso de Quality Assurance",
        "institucion": "Specialisterne y fundación Esplai",
        "periodo": "Marzo 2023 - Mayo 2023",
        "horas": 206 +" horas"
      }
      
    ]
  };
  let container = document.getElementById("data-container")
  let textInner= ""
  textInner="<ul>"
  for (var i=0;i<datosJSON.cursos.length; i++){
    textInner+="<li>"
    textInner+= datosJSON.cursos[i].nombre + " " 
    textInner+= datosJSON.cursos[i].institucion + " " 
    textInner+= datosJSON.cursos[i].periodo + " " 
    textInner+= datosJSON.cursos[i].horas;
    textInner+="</li>"
  }
  // aqui hacemos un json independiente y al mismo tiempo dinamizamos la informacion
  textInner += "</ul>"
  container.innerHTML= textInner;
 