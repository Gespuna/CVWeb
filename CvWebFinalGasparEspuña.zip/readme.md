1-Como se puede ver en primer lugar he creado un indice html5 y he continuado linkeando un script js.
2-Pulsa el link y abre en un navegador para poder ver la pagina web.
3-El Navbar es sacado de Bootstrap
4-los links al github van a mi cuenta y hay animaciones personalizadas para todas las imagenes
5-Hay una opción para descargar el Cv
6-Hay una opción para cambiar el color de la pagina en Jqueries
7-Hay un date() introducido a pie de pagina
8-La hoja de estilos esta en style.css y en las otras paginas se le ha aplicado el style desde el mismo html
9-Las imagenes estan en la carpeta assets
10-El codigo esta comentado
11-Hay un google font aplicado al h1
12-en el script del indice hay un evento onclick que inicia una funcion
13-Hay un formulario en contactos 
14-Hay Math en sobre mi
15-El Json independiente esta en educación y el Array en experiencia laboral
16-El formulario en Contactos esta validado en el scriptContacto.js
17-La pagina principal usa flex y grid con lo que es responsiva
18-Hay un Favicon en el head de cada pagina
19-Hay animaciones en toda la pagina
20-Hay iconos en la pagina index de Fontawesome que se pueden ver al descargar y en el lightmode y darkmode en el boton
21-Si hacemos multiples clics a darkmode y lightmode nos redirije a Google shopping huevos de pascua en Hospitalet 